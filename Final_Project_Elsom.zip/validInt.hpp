/***************************************
Program Name: Project 1
Author: Robert Elsom
Date: 1/10/2019
Description: Header file for validInt function
**************************************/

#ifndef VALID_INT_HPP
#define VALID_INT_HPP

int validInt(std::string prompt, int lowerLimit, int upperLimit);

#endif